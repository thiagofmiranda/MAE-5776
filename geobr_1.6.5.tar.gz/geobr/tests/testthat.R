library(testthat)
library(geobr)
library(sf)

test_check("geobr")
